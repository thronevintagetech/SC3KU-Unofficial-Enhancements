SC3KU CIVIC DEALS & EXTRA CHEATS v1.0 — PUBLIC RELEASE
========================================================

An unofficial fan-made enhancement for SimCity 3000 Unlimited for Windows.
The game is required and is not included.

This release extends the game through its native cheat, petitioner, budget,
disaster, flora and weather systems.

FEATURES
--------
forestfill
  Plants trees across eligible open terrain on the current map.

forestthicken
  Adds more trees to eligible terrain on an already forested map.

clouds on
  Requests the game's native rainy, cloudy weather mode. SC3KU may let the
  visible weather phase fade while its internal mode remains on. If that
  happens, enter clouds off and then clouds on to begin a fresh visible phase.

clouds off
  Releases the weather lock and requests the game's native clear-weather mode.

corruptncrazy
  Queues the Back Door Development Deal. After the mayor answers it, the WMT
  Redevelopment Offer is queued as a second, separate petitioner issue.

Back Door Development Deal
  Accept: 100,000 simoleans; Victor Stone's consortium receives first call on
  the city's preferred development area. No disaster.
  Reject: no money and no disaster.

WMT Redevelopment Offer
  Accept: 100,000 simoleans and one native tornado.
  Reject: no money and no tornado.

ORIGINAL EXTRA CHEATS
---------------------
The package includes the unmodified SC3KExtraCheats.dll by Null 45. Its
original commands, including dotcom, moolah and SimDate, remain available.
The upstream component is distributed under the included MIT License, whose
copyright notice identifies Nicholas Hayes.

REQUIRED GAME AND COMPATIBILITY
-------------------------------
Designed and tested against the US-English GOG and Steam resources for
SimCity 3000 Unlimited for Windows. The corresponding Steam and GOG US-English
text files and SYS.PAK source files were confirmed byte-for-byte identical
before v1.0 was built. Other languages and releases are not claimed as tested.

BACK UP FIRST
-------------
This public package intentionally contains no original game-file backups.
Before installing, create a backup folder OUTSIDE the game directory and copy
the files that this package will replace:

  Apps\Sys\SYS.PAK
  Apps\Res\Text\ENGLISH\Sc3StringsPetitionerAdvice.IXF
  Apps\Res\Text\ENGLISH\Sc3StringsPetitionerButton1.IXF
  Apps\Res\Text\ENGLISH\Sc3StringsPetitionerButton2.IXF
  Apps\Res\Text\ENGLISH\Sc3StringsPetitionerHeading.IXF
  Apps\Res\Text\ENGLISH\Sc3StringsPetitionerReaction1.IXF
  Apps\Res\Text\ENGLISH\Sc3StringsPetitionerReaction2.IXF

Also back up an existing Apps\SC3KExtraCheats.dll before replacing it.
Back up important city saves and use a copied city for the first test.

INSTALL
-------
1. Close SimCity 3000 Unlimited completely.
2. Complete the backup steps above.
3. Delete the old experimental Apps\SC3KCorruptCrazy.dll if present.
4. Copy everything INSIDE this package's Apps folder into the game's Apps
   folder. Merge folders and approve replacement of the listed files.
5. Confirm the game Apps folder contains:
     SC3KExtraCheats.dll   (unmodified upstream plugin by Null 45)
     SC3KCivicDeals.dll    (Civic Deals expansion)
6. Start the game and test with a copied city.

IMPORTANT
---------
WMT intentionally launches a real native tornado. Do not save over an important
city after an acceptance test.

OFFER LIFETIME
--------------
The custom sequence is available once per running game session. v1.0 gives
each offer 120 native update intervals. Restart the game to begin a fresh
sequence.

UNINSTALL / ROLLBACK
--------------------
Follow Documentation\ROLLBACK.txt. You must restore the original SYS.PAK and
six petitioner IXFs from your own pre-installation backup or use the storefront
client's repair/verification feature.

LEGAL NOTICE
------------
This is an unofficial fan project. It is not affiliated with, endorsed by or
supported by Electronic Arts or Maxis. SimCity, SimCity 3000 Unlimited and
related game assets are property of their respective owners. A legally obtained
copy of SimCity 3000 Unlimited is required.

See Documentation\TESTING.txt for verification tests.
See Documentation\ROLLBACK.txt to remove the mod.
See Documentation\TECHNICAL-NOTES.txt for compatibility details.
See Documentation\THIRD-PARTY-NOTICES.txt for upstream attribution.
