SIMCITY 3000 UNLIMITED — CLASSIC NATURAL WORLD v1.0
=====================================================

Public stable release • 5 September 2026

Classic Natural World is an unofficial visual enhancement for SimCity 3000
Unlimited. It modernizes the game's native terrain and water palettes while
preserving the original isometric artwork, grid readability and unmistakable
SC3KU character.

The game is required and is not included.

HIGHLIGHTS
----------
* Five refined terrain identities, including two deliberately distinct green
  landscapes, warm desert and savannah environments, and a rebuilt winter set
* Stronger elevation shading and a natural progression from habitable lowland
  through rocky high ground to bright, ice-shadowed snow caps
* A soft land-to-sand-to-water shoreline handoff without a turquoise wash
* Layered royal-blue, cobalt, sapphire and navy water that reveals useful depth
  in ordinary rivers, coves, ports and lakes—not only extreme trenches
* Richer contrast designed to remain coherent with buildings, roads, trees,
  bridges, marinas, ships and the game's visible grid
* Palette-native “smoke and mirrors”: no replacement renderer, new geometry,
  3D water, borrowed artwork or simulation changes

BACK UP FIRST
-------------
This public package intentionally contains no original game-file backups.
Before installing, create a backup folder OUTSIDE the game directory and copy:

  Apps\Res\Dirt\Palette\455A72B1_LandPalettes.IXF
  Apps\Res\Dirt\Palette\PALWATER.BMP
  Apps\Res\Dirt\Palette\PALEDGEL.BMP
  Apps\Res\Dirt\Palette\PALEDGED.BMP

Also back up important city saves and first test with a copied city.

INSTALLATION
------------
1. Exit SimCity 3000 Unlimited completely.
2. Complete the backup steps above.
3. Copy all four files from this package's Apps\Res\Dirt\Palette folder into
   the matching game folder and approve replacement.
4. Start the game and test with a copy of a city save.

Install all four v1.0 files together. Mixing files from older candidates may
produce mismatched water or shoreline colors.

ROLLBACK
--------
Exit the game and restore the four files from your own pre-installation backup.
Steam users may alternatively use Verify integrity of game files; GOG Galaxy
users may use Verify / Repair.

COMPATIBILITY AND SCOPE
-----------------------
This release targets SimCity 3000 Unlimited for Windows and was tested using
the Steam palette-directory layout. Other releases with the same
Apps\Res\Dirt\Palette structure may work, but are not claimed as tested.
The palette files do not change city saves, simulation rules, buildings,
terrain geometry or screen resolution.

LEGAL NOTICE
------------
Use a legally obtained copy of SimCity 3000 Unlimited. This is an unofficial
fan project and is not affiliated with, endorsed by or supported by Electronic
Arts or Maxis. SimCity, SimCity 3000 Unlimited and related game assets are
property of their respective owners.

PRIVACY
-------
The package contains no personal name, account data, savegame, machine path,
storefront identifier or other user-specific information.

STATUS
------
Stable v1.0. The four gameplay files are byte-for-byte identical to the final
approved and gameplay-tested RC9 candidate. No untested visual change was
introduced during public-release packaging.

